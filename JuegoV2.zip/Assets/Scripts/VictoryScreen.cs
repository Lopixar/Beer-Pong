using TMPro;
using UnityEngine;

// Controller of the victory overlay.
// The visuals (panel, texts, buttons, confetti) are built at runtime by MobileUIStyler,
// so it matches the menus, this script only fills in the numbers and shows / hides it.
// BallThrower decides when the player wins (see "Cups To Win" in its inspector).
public class VictoryScreen : MonoBehaviour
{
    public static VictoryScreen Instance { get; private set; }

    [HideInInspector] public GameObject panel;
    [HideInInspector] public TMP_Text subtitle;
    [HideInInspector] public TMP_Text cupsValue;
    [HideInInspector] public TMP_Text throwsValue;
    [HideInInspector] public TMP_Text accuracyValue;

    public bool IsVisible
    {
        get { return panel != null && panel.activeSelf; }
    }

    void Awake()
    {
        Instance = this;
    }

    void OnDestroy()
    {
        if (Instance == this)
            Instance = null;
    }

    public void Show(int cupsHit, int cupsTotal, int throwsUsed)
    {
        if (panel == null)
            return;

        bool allCups = cupsTotal > 0 && cupsHit >= cupsTotal;

        if (subtitle != null)
            subtitle.text = allCups ? GameTexts.VictoryAllCups : GameTexts.VictoryTarget;

        if (cupsValue != null)
            cupsValue.text = cupsTotal > 0 ? cupsHit + "/" + cupsTotal : cupsHit.ToString();

        if (throwsValue != null)
            throwsValue.text = throwsUsed.ToString();

        if (accuracyValue != null)
        {
            accuracyValue.text = throwsUsed > 0
                ? Mathf.Min(100, Mathf.RoundToInt(100f * cupsHit / throwsUsed)) + "%"
                : "-";
        }

        // fills in the texts first, so the intro animation already shows the final numbers
        panel.SetActive(true);
    }

    public void Hide()
    {
        if (panel != null)
            panel.SetActive(false);
    }
}
